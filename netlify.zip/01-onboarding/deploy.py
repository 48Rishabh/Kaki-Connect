#!/usr/bin/env python3
"""
Deploy KakiConnect prototype to Netlify (no account needed via direct zip upload).
Falls back to tiiny.host if Netlify fails.
"""

import ssl, urllib.request, json, os, sys

zip_path = "/tmp/kakiconnect-proto.zip"

# SSL context that works even without local certs installed
ctx = ssl.create_default_context()
try:
    ctx.load_default_certs()
except Exception:
    pass
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE

with open(zip_path, "rb") as f:
    zip_data = f.read()

print(f"[deploy] zip size: {len(zip_data):,} bytes")

# ── Option 1: Netlify anonymous site deploy (zip) ──────────────────────
print("[deploy] Trying Netlify...")
req = urllib.request.Request(
    "https://api.netlify.com/api/v1/sites",
    data=zip_data,
    headers={"Content-Type": "application/zip"},
    method="POST",
)
try:
    with urllib.request.urlopen(req, timeout=60, context=ctx) as resp:
        body = json.loads(resp.read().decode())
        url = body.get("ssl_url") or body.get("url") or body.get("deploy_url")
        if url:
            print(f"\n✅  LIVE URL: {url}\n")
            sys.exit(0)
        else:
            print("[deploy] Netlify responded but no URL found:", body)
except Exception as e:
    print(f"[deploy] Netlify error: {e}")

# ── Option 2: tiiny.host ──────────────────────────────────────────────
print("[deploy] Trying tiiny.host...")
req2 = urllib.request.Request(
    "https://tiiny.host/api/upload",
    data=zip_data,
    headers={
        "Content-Type": "application/zip",
        "tiiny-subdomain": "kakiconnect-onboarding",
        "tiiny-password": "",
        "file-type": "zip",
    },
    method="POST",
)
try:
    with urllib.request.urlopen(req2, timeout=60, context=ctx) as resp:
        body = resp.read().decode()
        print(f"\n✅  Response: {body}\n")
        sys.exit(0)
except Exception as e:
    print(f"[deploy] tiiny.host error: {e}")

print("\n❌  All deploy attempts failed. See instructions above.")
